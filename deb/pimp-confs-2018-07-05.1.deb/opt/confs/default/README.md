# PiMPconfs
### Author: Portable Instant Mining Platform LLC

PiMP OS managed configuration files for crypto currency miners

Licensed exclusively for use with PiMP and Miner.farm software.

